param(
    [string]$Root = "D:\Website Portofolio Parjo",
    [string]$Prefix = 'http://localhost:8000/'
)

[System.Net.ServicePointManager]::DefaultConnectionLimit = 100
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($Prefix)
try {
    $listener.Start()
    Write-Output "HttpListener started on $Prefix, serving from $Root"
    while ($listener.IsListening) {
        try {
            $context = $listener.GetContext()
            $req = $context.Request
            $path = $req.Url.LocalPath.TrimStart('/')
            if ($path -eq '') { $path = 'index.html' }
            $file = Join-Path $Root $path
            if (Test-Path $file) {
                $bytes = [System.IO.File]::ReadAllBytes($file)
                $ext = [System.IO.Path]::GetExtension($file).ToLower()
                switch ($ext) {
                    '.html' { $context.Response.ContentType = 'text/html' }
                    '.css'  { $context.Response.ContentType = 'text/css' }
                    '.js'   { $context.Response.ContentType = 'application/javascript' }
                    '.png'  { $context.Response.ContentType = 'image/png' }
                    '.jpg'  { $context.Response.ContentType = 'image/jpeg' }
                    '.jpeg' { $context.Response.ContentType = 'image/jpeg' }
                    '.svg'  { $context.Response.ContentType = 'image/svg+xml' }
                    default { $context.Response.ContentType = 'application/octet-stream' }
                }
                $context.Response.OutputStream.Write($bytes,0,$bytes.Length)
            } else {
                $context.Response.StatusCode = 404
                $msg = [System.Text.Encoding]::UTF8.GetBytes('404 Not Found')
                $context.Response.OutputStream.Write($msg,0,$msg.Length)
            }
            $context.Response.Close()
        } catch {
            Write-Output "Listener loop error: $_"
        }
    }
} catch {
    Write-Output "Failed to start HttpListener: $_"
} finally {
    if ($listener -and $listener.IsListening) { $listener.Stop() }
}
