param(
  [int]$Port = 8000
)

Write-Host "Starting local server in: $PWD`nPort: $Port`n"

function Start-Python {
  $py = Get-Command python -ErrorAction SilentlyContinue
  if (-not $py) { $py = Get-Command python3 -ErrorAction SilentlyContinue }
  if ($py) {
    Write-Host "Found Python: $($py.Path). Starting http.server...`n"
    & $py.Path -m http.server $Port
    return $true
  }
  return $false
}

function Start-NodeNpx {
  $npx = Get-Command npx -ErrorAction SilentlyContinue
  if ($npx) {
    Write-Host "Found npx. Starting http-server via npx...`n"
    & npx http-server -p $Port
    return $true
  }
  return $false
}

function Start-NodeFallback {
  $node = Get-Command node -ErrorAction SilentlyContinue
  if ($node) {
    Write-Host "Found node.exe at $($node.Path). Attempting to run npx http-server...`n"
    & npx http-server -p $Port
    return $true
  }
  return $false
}

if (-not (Start-Python)) {
  if (-not (Start-NodeNpx)) {
    if (-not (Start-NodeFallback)) {
      Write-Host "\nNo suitable server runtime found. Please install one of the following or use VS Code Live Server extension:\n- Python 3 (add to PATH)\n- Node.js (with npx)\n\nYou can also open index.html directly in the browser, but some features (like fetch) may require a local server."
      exit 2
    }
  }
}
